var jugadorActual = "jugador1";

function jugarMichi(btn) {
    if (!btn.innerHTML) {
        btn.innerHTML = jugar();
        verificarGanador();
    }
}

function jugar() {
    var marca = "";
    if (jugadorActual == "jugador1") {
        marca = "X";
        jugadorActual = "jugador2";
    } else {
        marca = "O";
        jugadorActual = "jugador1";
    }
    return marca;
}


var listaVerificacion = [[0, 1, 2], [3, 4, 5], [6, 7, 8],[0, 3, 6], [1, 4, 7], [2, 5, 8],[0, 4, 8], [2, 4, 6]
];

var botones = document.querySelectorAll(".botonMichi");
function verificarGanador() {
    var mensaje = "";
    for (var j = 0; j < listaVerificacion.length; j++) {
        if (botones[listaVerificacion[j][0]].innerHTML === "X" && botones[listaVerificacion[j][1]].innerHTML === "X" && botones[listaVerificacion[j][2]].innerHTML === "X") {
            alert("Marca X gana");
            bloquearBotones();
            return false;
        } else if (botones[listaVerificacion[j][0]].innerHTML === "O" && botones[listaVerificacion[j][1]].innerHTML === "O" && botones[listaVerificacion[j][2]].innerHTML === "O") {
            alert("Marca O gana");
            bloquearBotones();
            return false;
        } else if (botones[0].innerHTML != "" && botones[1].innerHTML != "" && botones[2].innerHTML != "" && botones[3].innerHTML !== "" && botones[4].innerHTML != "" && botones[5].innerHTML != "" && botones[6].innerHTML != "" && botones[7].innerHTML != "" && botones[8].innerHTML != "") {
            alert("Empate");
            bloquearBotones();
            return false;
        }
    }    
}

function bloquearBotones(){
    for (var i = 0; i < botones.length; i++) {
        botones[i].disabled = true;
    }   
}